import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Search, Sun, Moon, RefreshCw, Settings, Bookmark, BookmarkCheck,
  X, Plus, Check, ChevronRight, ExternalLink, Trash2, Bell, MapPin,
  Inbox, AlertCircle, ArrowUp, Globe, Eye, Sparkles, Radio, Clock
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Konstanten                                                         */
/* ------------------------------------------------------------------ */

const APP_NAME = "RADAR";

const DEFAULT_CATEGORIES = [
  { id: "local",      name: "Mittelbaden",            short: "Lokal",      isLocal: true },
  { id: "politik",    name: "Politik & Welt",         short: "Politik" },
  { id: "wirtschaft", name: "Wirtschaft & Börse",     short: "Wirtschaft" },
  { id: "ki",         name: "Künstliche Intelligenz", short: "KI" },
  { id: "security",   name: "IT-Sicherheit",          short: "Security" },
  { id: "pc",         name: "PC & Hardware",          short: "Hardware" },
  { id: "mobile",     name: "Smartphones & Gadgets",  short: "Mobile" },
  { id: "space",      name: "Raumfahrt & Astronomie", short: "Raumfahrt" },
  { id: "auto",       name: "Auto & Mobilität",       short: "Auto" },
  { id: "gaming",     name: "Gaming",                 short: "Gaming" },
  { id: "sport",      name: "Sport",                  short: "Sport" },
  { id: "kampfsport", name: "Kampfsport",             short: "Kampfsport" },
  { id: "gesundheit", name: "Gesundheit & Medizin",   short: "Gesundheit" },
  { id: "kultur",     name: "Film, Serien & Musik",   short: "Kultur" },
];

// Pro Kategorie mehrere seriöse RSS-Feeds. Fällt einer aus, liefern die anderen.
const FEEDS = {
  local: [
    { name: "SWR Aktuell BW", url: "https://www.swr.de/~rss/swraktuell/swraktuell-bw-100.xml" },
  ],
  politik: [
    { name: "tagesschau Inland", url: "https://www.tagesschau.de/inland/index~rss2.xml" },
    { name: "tagesschau Ausland", url: "https://www.tagesschau.de/ausland/index~rss2.xml" },
  ],
  wirtschaft: [
    { name: "tagesschau Wirtschaft", url: "https://www.tagesschau.de/wirtschaft/index~rss2.xml" },
  ],
  ki: [
    { name: "The Decoder", url: "https://the-decoder.de/feed/" },
    { name: "t3n", url: "https://t3n.de/rss.xml" },
  ],
  security: [
    { name: "heise Security", url: "https://www.heise.de/security/rss/news-atom.xml" },
    { name: "BleepingComputer", url: "https://www.bleepingcomputer.com/feed/" },
  ],
  pc: [
    { name: "ComputerBase", url: "https://www.computerbase.de/rss/news.xml" },
    { name: "heise", url: "https://www.heise.de/rss/heise-atom.xml" },
  ],
  mobile: [
    { name: "GSMArena", url: "https://www.gsmarena.com/rss-news-reviews.php3" },
    { name: "ComputerBase", url: "https://www.computerbase.de/rss/news.xml" },
  ],
  space: [
    { name: "astronews", url: "https://www.astronews.com/rss/news.xml" },
    { name: "Spektrum", url: "https://www.spektrum.de/alias/rss/spektrum-de-rss-feed/996406" },
  ],
  auto: [
    { name: "electrive", url: "https://www.electrive.net/feed/" },
    { name: "auto motor und sport", url: "https://www.auto-motor-und-sport.de/rss/feed/" },
  ],
  gaming: [
    { name: "GameStar", url: "https://www.gamestar.de/news/rss/news.rss" },
    { name: "PC Games", url: "https://www.pcgames.de/feed.cfm" },
  ],
  sport: [
    { name: "kicker", url: "https://newsfeed.kicker.de/news/aktuell" },
    { name: "SWR Sport", url: "https://www.swr.de/~rss/sport/sport-aktuell-102.xml" },
  ],
  kampfsport: [
    { name: "Sherdog", url: "https://www.sherdog.com/rss/news.xml" },
  ],
  gesundheit: [
    { name: "Ärzteblatt", url: "https://www.aerzteblatt.de/rss/news.asp" },
  ],
  kultur: [
    { name: "Spiegel Kultur", url: "https://www.spiegel.de/kultur/index.rss" },
  ],
};

// Für eigene Themen und die freie Suche: Google-News-RSS nach Stichwort.
function googleNewsFeed(query) {
  return {
    name: "Google News",
    gnews: true,
    url: `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=de&gl=DE&ceid=DE:de`,
  };
}

// CORS-Umwege: erst zwei öffentliche Proxys, dann direkter Versuch.
const PROXIES = [
  (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
];

/* ------------------------------------------------------------------ */
/*  Hilfsfunktionen                                                    */
/* ------------------------------------------------------------------ */

function hashStr(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

function domainFromUrl(url) {
  try {
    const h = new URL(url).hostname.replace(/^www\./, "");
    return h;
  } catch {
    return "Quelle";
  }
}

function timeAgo(ts) {
  if (!ts) return "";
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 45) return "gerade eben";
  const m = Math.floor(s / 60);
  if (m < 60) return `vor ${m} Min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `vor ${h} Std`;
  const d = Math.floor(h / 24);
  return `vor ${d} Tg`;
}

function formatArticleDate(d) {
  if (!d) return "";
  const m = /(\d{4})-(\d{2})-(\d{2})/.exec(d);
  if (m) {
    const dt = new Date(`${m[1]}-${m[2]}-${m[3]}T12:00:00`);
    if (!isNaN(dt.getTime())) {
      const a = new Date(); a.setHours(0, 0, 0, 0);
      const b = new Date(dt); b.setHours(0, 0, 0, 0);
      const diff = Math.round((a.getTime() - b.getTime()) / 86400000);
      if (diff === 0) return "heute";
      if (diff === 1) return "gestern";
      if (diff > 1 && diff < 7) return `vor ${diff} Tagen`;
      return dt.toLocaleDateString("de-DE", { day: "2-digit", month: "short" });
    }
  }
  return String(d).slice(0, 24);
}

function stripHtml(html) {
  if (!html) return "";
  try {
    const d = new DOMParser().parseFromString(String(html), "text/html");
    return (d.body.textContent || "").replace(/\s+/g, " ").trim();
  } catch {
    return String(html).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
  }
}

function toTimestamp(dateStr) {
  if (!dateStr) return 0;
  const t = Date.parse(dateStr);
  return isNaN(t) ? 0 : t;
}

// Anzeigefilter: "heute" = letzte 48 Std, "7days" = letzte 8 Tage.
// Meldungen ohne verwertbares Datum werden immer gezeigt.
function passesRange(a, range) {
  if (!a.ts) return true;
  const age = Date.now() - a.ts;
  if (range === "7days") return age < 8 * 86400000;
  return age < 48 * 3600000;
}

function parseFeed(xmlText, feed, cat) {
  let doc;
  try {
    doc = new DOMParser().parseFromString(xmlText, "text/xml");
  } catch {
    return [];
  }
  if (!doc || doc.querySelector("parsererror")) return [];

  const nodes = doc.querySelectorAll("item, entry");
  const out = [];
  nodes.forEach((node) => {
    const txt = (sel) => {
      const el = node.querySelector(sel);
      return el ? el.textContent.trim() : "";
    };
    let title = txt("title");
    // Link: RSS <link>text</link> oder Atom <link href=".." rel="alternate" />
    let link = "";
    const linkAlt = node.querySelector('link[rel="alternate"]');
    const linkAny = node.querySelector("link");
    if (linkAlt && linkAlt.getAttribute("href")) link = linkAlt.getAttribute("href");
    else if (linkAny) link = linkAny.getAttribute("href") || linkAny.textContent.trim();

    const descRaw = txt("description") || txt("summary") || txt("content");
    const date = txt("pubDate") || txt("published") || txt("updated") || txt("date");

    let sourceName = feed.name;
    // Google News: Titel ist "Schlagzeile - Quelle", Quelle zusätzlich in <source>
    if (feed.gnews) {
      const src = txt("source");
      const dash = title.lastIndexOf(" - ");
      if (dash > 0 && title.length - dash < 42) {
        sourceName = src || title.slice(dash + 3).trim();
        title = title.slice(0, dash).trim();
      } else if (src) {
        sourceName = src;
      }
    }

    if (!title || !link) return;
    const ts = toTimestamp(date);
    out.push({
      id: `${cat.id}-${hashStr(title + "|" + link)}`,
      categoryId: cat.id,
      headline: title,
      summary: stripHtml(descRaw).slice(0, 240),
      date: ts ? new Date(ts).toISOString() : "",
      ts,
      importance: 2,
      sources: [{ name: sourceName, url: link }],
      fetchedAt: Date.now(),
    });
  });
  return out;
}

async function fetchViaProxy(url, signal) {
  const attempts = [...PROXIES.map((p) => p(url)), url];
  let lastErr = null;
  for (const attempt of attempts) {
    try {
      const res = await fetch(attempt, { signal });
      if (!res.ok) { lastErr = new Error(`HTTP ${res.status}`); continue; }
      const text = await res.text();
      if (text && text.length > 60) return text;
      lastErr = new Error("Leere Antwort");
    } catch (e) {
      if (e.name === "AbortError") throw e;
      lastErr = e;
    }
  }
  throw lastErr || new Error("nicht erreichbar");
}

async function fetchCategoryFeeds(cat, signal) {
  const feeds = cat.custom ? [googleNewsFeed(cat.name)] : (FEEDS[cat.id] || []);
  if (!feeds.length) return [];
  const results = await Promise.allSettled(
    feeds.map(async (f) => {
      const xml = await fetchViaProxy(f.url, signal);
      return parseFeed(xml, f, cat);
    })
  );
  const anyOk = results.some((r) => r.status === "fulfilled");
  if (!anyOk) {
    const reason = results[0] && results[0].reason;
    throw new Error((reason && reason.message) || "Feeds nicht erreichbar");
  }
  let items = [];
  results.forEach((r) => { if (r.status === "fulfilled") items = items.concat(r.value); });
  const seen = new Set();
  items = items.filter((a) => {
    const key = (a.sources[0] && a.sources[0].url) || a.headline;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  items.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  return items.slice(0, 30);
}

/* ------------------------------------------------------------------ */
/*  Persistenz (window.storage mit Fallback)                          */
/* ------------------------------------------------------------------ */

const mem = {};
const store = {
  async get(key, fallback) {
    try {
      if (typeof window !== "undefined" && window.storage) {
        const r = await window.storage.get(key);
        if (r && typeof r.value === "string") return JSON.parse(r.value);
        return fallback;
      }
    } catch { /* ignore */ }
    try {
      if (typeof localStorage !== "undefined") {
        const v = localStorage.getItem("radar:" + key);
        if (v != null) return JSON.parse(v);
        return fallback;
      }
    } catch { /* ignore */ }
    return key in mem ? mem[key] : fallback;
  },
  async set(key, value) {
    mem[key] = value;
    try {
      if (typeof window !== "undefined" && window.storage) {
        await window.storage.set(key, JSON.stringify(value));
        return;
      }
    } catch { /* ignore */ }
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem("radar:" + key, JSON.stringify(value));
      }
    } catch { /* ignore */ }
  },
};

const FRESH_MS = 60 * 60 * 1000; // 1 Stunde

/* ------------------------------------------------------------------ */
/*  Styles                                                             */
/* ------------------------------------------------------------------ */

const STYLES = `
:root{
  --bg:#FAF9F7; --surface:#FFFFFF; --surface-2:#F4F2EF; --surface-3:#ECE8E2;
  --border:#E7E2DB; --border-strong:#D8D2C8;
  --text:#211C17; --text-2:#6B6258; --text-3:#A39A8E;
  --accent:#CB6A4B; --accent-hover:#B5573A; --accent-soft:#FBEDE7;
  --accent-ring:rgba(203,106,75,.32);
  --good:#3F8F6B;
  --shadow-sm:0 1px 2px rgba(33,28,23,.05),0 1px 3px rgba(33,28,23,.05);
  --shadow-md:0 2px 6px rgba(33,28,23,.06),0 10px 28px rgba(33,28,23,.07);
  --r-sm:9px; --r-md:13px; --r-lg:18px; --r-xl:24px;
  --fd:"Space Grotesk",system-ui,-apple-system,sans-serif;
  --fb:"Inter",system-ui,-apple-system,sans-serif;
  --fm:"JetBrains Mono",ui-monospace,"SF Mono",Menlo,monospace;
}
[data-theme="dark"]{
  --bg:#16130E; --surface:#201C16; --surface-2:#29241D; --surface-3:#332E26;
  --border:#37312A; --border-strong:#4A4339;
  --text:#F5F1E9; --text-2:#ADA396; --text-3:#7B7165;
  --accent:#E08763; --accent-hover:#EC9879; --accent-soft:#2D2118;
  --accent-ring:rgba(224,135,99,.35);
  --good:#5DBB8D;
  --shadow-sm:0 1px 2px rgba(0,0,0,.35);
  --shadow-md:0 6px 24px rgba(0,0,0,.45);
}
*{box-sizing:border-box}
.app{
  min-height:100vh; background:var(--bg); color:var(--text);
  font-family:var(--fb); font-size:15px; line-height:1.5;
  -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility;
  transition:background .35s ease,color .35s ease;
}
.app *::selection{background:var(--accent-ring)}
.app button{font-family:inherit; cursor:pointer; border:none; background:none; color:inherit}
.app a{color:inherit; text-decoration:none}
.app input{font-family:inherit}
.app button:focus-visible,.app a:focus-visible,.app [role="switch"]:focus-visible{
  outline:2px solid var(--accent); outline-offset:2px; border-radius:9px;
}
.app input:focus-visible{outline:none}
html{background:var(--bg)} html[data-theme="dark"]{--bg:#16130E}
body{background:var(--bg); margin:0}

/* Header */
.hdr{
  position:sticky; top:0; z-index:40;
  background:var(--bg);
  background:color-mix(in srgb,var(--bg) 82%,transparent);
  backdrop-filter:saturate(150%) blur(14px);
  -webkit-backdrop-filter:saturate(150%) blur(14px);
  border-bottom:1px solid var(--border);
}
.hdr-in{max-width:780px; margin:0 auto; padding:13px 16px 12px; display:flex; align-items:center; gap:12px}
.brand{display:flex; align-items:baseline; gap:9px; min-width:0}
.brand-mark{
  font-family:var(--fd); font-weight:700; font-size:21px; letter-spacing:.14em;
  color:var(--text);
}
.brand-sub{
  font-family:var(--fm); font-size:9.5px; letter-spacing:.18em; font-weight:500;
  color:var(--text-3); text-transform:uppercase; white-space:nowrap;
  display:flex; align-items:center; gap:6px;
}
.pulse{position:relative; width:7px; height:7px; flex:none}
.pulse span{position:absolute; inset:0; border-radius:50%; background:var(--accent)}
.pulse span::after{
  content:""; position:absolute; inset:0; border-radius:50%; background:var(--accent);
  animation:ping 2.1s cubic-bezier(0,0,.2,1) infinite;
}
@keyframes ping{0%{transform:scale(1);opacity:.7}75%,100%{transform:scale(3.2);opacity:0}}
.hdr-actions{margin-left:auto; display:flex; align-items:center; gap:2px}
.iconbtn{
  width:38px; height:38px; border-radius:11px; display:grid; place-items:center;
  color:var(--text-2); transition:background .18s,color .18s,transform .12s; position:relative;
}
.iconbtn:hover{background:var(--surface-2); color:var(--text)}
.iconbtn:active{transform:scale(.92)}
.iconbtn.on{color:var(--accent); background:var(--accent-soft)}
.iconbtn .dot{position:absolute; top:7px; right:7px; width:7px; height:7px; border-radius:50%;
  background:var(--accent); border:2px solid var(--bg)}
.spin{animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* Chips */
.chips-wrap{border-bottom:1px solid var(--border); background:var(--bg)}
.chips{
  max-width:780px; margin:0 auto; padding:11px 16px; display:flex; gap:8px;
  overflow-x:auto; scrollbar-width:none;
}
.chips::-webkit-scrollbar{display:none}
.chip{
  flex:none; padding:7px 13px; border-radius:999px; font-size:13px; font-weight:500;
  color:var(--text-2); background:var(--surface-2); border:1px solid transparent;
  white-space:nowrap; transition:all .16s; display:flex; align-items:center; gap:6px;
}
.chip:hover{color:var(--text); border-color:var(--border-strong)}
.chip.active{background:var(--accent); color:#fff; box-shadow:var(--shadow-sm)}
.chip.local{}
.chip.active.local{background:var(--accent)}

/* Range toggle */
.subbar{max-width:780px; margin:0 auto; padding:10px 16px 0; display:flex; align-items:center; gap:10px}
.seg{display:inline-flex; background:var(--surface-2); border-radius:10px; padding:3px; gap:2px}
.seg button{padding:5px 12px; border-radius:8px; font-size:12.5px; font-weight:500; color:var(--text-2);
  font-family:var(--fm); letter-spacing:.02em; transition:all .16s}
.seg button.active{background:var(--surface); color:var(--text); box-shadow:var(--shadow-sm)}
.subbar-note{margin-left:auto; font-family:var(--fm); font-size:10.5px; color:var(--text-3);
  letter-spacing:.04em; display:flex; align-items:center; gap:5px}

/* Layout */
.main{max-width:780px; margin:0 auto; padding:8px 16px 96px}
.section{margin-top:26px}
.section.first{margin-top:18px}
.sec-head{display:flex; align-items:center; gap:9px; margin-bottom:13px; padding:0 2px}
.sec-rail{width:3px; height:15px; border-radius:2px; background:var(--border-strong)}
.section.local .sec-rail{background:var(--accent)}
.sec-title{font-family:var(--fd); font-weight:600; font-size:15.5px; letter-spacing:.01em; color:var(--text)}
.section.local .sec-title{color:var(--accent)}
.sec-count{font-family:var(--fm); font-size:10.5px; color:var(--text-3); letter-spacing:.05em}
.sec-loc-tag{margin-left:auto; font-family:var(--fm); font-size:10px; color:var(--text-3);
  letter-spacing:.1em; text-transform:uppercase; display:flex; align-items:center; gap:5px}

/* Card */
.card{
  background:var(--surface); border:1px solid var(--border); border-radius:var(--r-lg);
  padding:16px 17px 13px; margin-bottom:11px; box-shadow:var(--shadow-sm);
  transition:border-color .2s,box-shadow .2s,transform .2s,opacity .3s;
  animation:rise .5s cubic-bezier(.2,.7,.3,1) both;
}
.card:hover{border-color:var(--border-strong); box-shadow:var(--shadow-md); transform:translateY(-1px)}
.card.top{border-color:var(--accent-soft)}
.card.top:hover{border-color:var(--accent)}
.card.read{opacity:.55}
.card.read:hover{opacity:.8}
@keyframes rise{from{opacity:0; transform:translateY(10px)}to{opacity:1; transform:translateY(0)}}
.card-top{display:flex; align-items:center; gap:8px; margin-bottom:8px; flex-wrap:wrap}
.tag{font-family:var(--fm); font-size:9.5px; font-weight:600; letter-spacing:.1em; text-transform:uppercase;
  padding:3px 7px; border-radius:6px; background:var(--surface-2); color:var(--text-3)}
.tag.cat{color:var(--text-2)}
.tag.new{background:var(--accent); color:#fff; letter-spacing:.12em}
.tag.topstory{background:var(--accent-soft); color:var(--accent)}
.headline{font-family:var(--fd); font-weight:600; font-size:17.5px; line-height:1.28; letter-spacing:-.005em;
  color:var(--text); margin:1px 0 7px}
.summary{font-size:14.5px; line-height:1.55; color:var(--text-2); margin:0 0 13px}
.card-foot{display:flex; flex-direction:column; gap:10px}
.sources{display:flex; flex-wrap:wrap; gap:7px}
.src{
  display:inline-flex; align-items:center; gap:5px; padding:5px 9px; border-radius:8px;
  background:var(--surface-2); border:1px solid var(--border); font-family:var(--fm);
  font-size:11.5px; font-weight:500; color:var(--text-2); transition:all .16s; max-width:100%;
}
.src:hover{background:var(--accent-soft); border-color:var(--accent); color:var(--accent)}
.src svg{flex:none; opacity:.7}
.src .nm{overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:160px}
.foot-row{display:flex; align-items:center; gap:6px}
.foot-meta{font-family:var(--fm); font-size:11px; color:var(--text-3); letter-spacing:.03em;
  display:flex; align-items:center; gap:6px; margin-right:auto}
.dotsep{width:3px; height:3px; border-radius:50%; background:var(--text-3); opacity:.6}
.act{width:32px; height:32px; border-radius:9px; display:grid; place-items:center; color:var(--text-3);
  transition:all .16s}
.act:hover{background:var(--surface-2); color:var(--text)}
.act.saved{color:var(--accent)}
.act.isread{color:var(--good)}

/* Skeleton */
.sk{background:var(--surface); border:1px solid var(--border); border-radius:var(--r-lg);
  padding:16px 17px; margin-bottom:11px; box-shadow:var(--shadow-sm)}
.sk-line{height:12px; border-radius:6px; background:linear-gradient(90deg,var(--surface-2) 25%,var(--surface-3) 37%,var(--surface-2) 63%);
  background-size:400% 100%; animation:sh 1.4s ease infinite; margin-bottom:9px}
@keyframes sh{0%{background-position:100% 0}100%{background-position:-100% 0}}

/* States */
.state{text-align:center; padding:54px 24px; color:var(--text-3)}
.state .ic{width:54px; height:54px; border-radius:16px; background:var(--surface-2); display:grid;
  place-items:center; margin:0 auto 16px; color:var(--text-3)}
.state h3{font-family:var(--fd); font-weight:600; font-size:16px; color:var(--text-2); margin:0 0 6px}
.state p{font-size:13.5px; margin:0 auto; max-width:300px; line-height:1.55}
.retry{margin-top:16px; display:inline-flex; align-items:center; gap:7px; padding:9px 16px;
  border-radius:11px; background:var(--surface-2); color:var(--text); font-size:13px; font-weight:500;
  border:1px solid var(--border); transition:all .16s}
.retry:hover{background:var(--surface-3); border-color:var(--border-strong)}
.cat-error{display:flex; align-items:center; gap:10px; padding:13px 15px; border-radius:var(--r-md);
  background:var(--surface); border:1px dashed var(--border-strong); color:var(--text-2); font-size:13px}
.cat-error button{margin-left:auto; color:var(--accent); font-weight:500; font-size:12.5px; display:flex; align-items:center; gap:5px}

/* Banner */
.banner{max-width:780px; margin:14px auto 0; padding:0 16px}
.banner-in{display:flex; align-items:center; gap:13px; padding:14px 16px; border-radius:var(--r-lg);
  background:var(--accent-soft); border:1px solid var(--accent); box-shadow:var(--shadow-sm)}
.banner-ic{width:38px; height:38px; border-radius:11px; background:var(--accent); color:#fff; display:grid; place-items:center; flex:none}
.banner-tx{min-width:0}
.banner-tx b{font-family:var(--fd); font-size:14.5px; color:var(--text); display:block}
.banner-tx span{font-size:12.5px; color:var(--text-2)}
.banner-go{margin-left:auto; flex:none; padding:8px 14px; border-radius:10px; background:var(--accent); color:#fff;
  font-weight:600; font-size:13px; display:flex; align-items:center; gap:6px; transition:all .16s}
.banner-go:hover{background:var(--accent-hover)}
.banner-x{flex:none; width:30px; height:30px; border-radius:9px; display:grid; place-items:center; color:var(--text-2)}
.banner-x:hover{background:rgba(0,0,0,.05)}

/* Overlay panel */
.scrim{position:fixed; inset:0; z-index:60; background:rgba(20,15,10,.42); backdrop-filter:blur(2px);
  animation:fade .2s ease; display:flex; justify-content:flex-end}
@keyframes fade{from{opacity:0}to{opacity:1}}
.panel{width:min(420px,100%); height:100%; background:var(--bg); box-shadow:var(--shadow-md);
  display:flex; flex-direction:column; animation:slide .28s cubic-bezier(.2,.7,.3,1)}
@keyframes slide{from{transform:translateX(100%)}to{transform:translateX(0)}}
.panel-hd{display:flex; align-items:center; gap:10px; padding:16px; border-bottom:1px solid var(--border)}
.panel-hd h2{font-family:var(--fd); font-weight:600; font-size:17px; margin:0}
.panel-hd .iconbtn{margin-left:auto}
.panel-body{flex:1; overflow-y:auto; padding:18px 16px 40px}
.pgroup{margin-bottom:26px}
.pgroup-t{font-family:var(--fm); font-size:10.5px; letter-spacing:.12em; text-transform:uppercase;
  color:var(--text-3); margin:0 2px 11px; display:flex; align-items:center; gap:7px}
.catrow{display:flex; align-items:center; gap:11px; padding:11px 12px; border-radius:var(--r-md);
  background:var(--surface); border:1px solid var(--border); margin-bottom:8px}
.catrow .nm{font-size:14px; font-weight:500}
.catrow .nm small{display:block; font-family:var(--fm); font-size:10px; color:var(--text-3); letter-spacing:.04em; margin-top:2px; font-weight:400}
.catrow.local .nm{color:var(--accent)}
.catrow .rm{margin-left:auto; width:30px; height:30px; border-radius:8px; display:grid; place-items:center; color:var(--text-3)}
.catrow .rm:hover{color:var(--accent); background:var(--accent-soft)}
.switch{margin-left:auto; width:42px; height:25px; border-radius:999px; background:var(--surface-3);
  position:relative; transition:background .2s; flex:none}
.switch.on{background:var(--accent)}
.switch i{position:absolute; top:3px; left:3px; width:19px; height:19px; border-radius:50%; background:#fff;
  box-shadow:0 1px 3px rgba(0,0,0,.25); transition:transform .2s}
.switch.on i{transform:translateX(17px)}
.addrow{display:flex; gap:8px; margin-top:4px}
.inp{flex:1; padding:11px 13px; border-radius:var(--r-md); background:var(--surface); border:1px solid var(--border);
  font-size:14px; color:var(--text); outline:none; transition:border-color .16s,box-shadow .16s}
.inp:focus{border-color:var(--accent); box-shadow:0 0 0 3px var(--accent-ring)}
.inp::placeholder{color:var(--text-3)}
.btn-p{padding:0 15px; border-radius:var(--r-md); background:var(--accent); color:#fff; font-weight:600; font-size:13.5px;
  display:flex; align-items:center; gap:6px; transition:background .16s}
.btn-p:hover{background:var(--accent-hover)}
.btn-p:disabled{opacity:.5; cursor:not-allowed}
.timepick{display:flex; align-items:center; gap:11px; padding:13px; border-radius:var(--r-md);
  background:var(--surface); border:1px solid var(--border)}
.timepick input{padding:9px 12px; border-radius:9px; background:var(--surface-2); border:1px solid var(--border);
  color:var(--text); font-family:var(--fm); font-size:15px; outline:none; color-scheme:light}
[data-theme="dark"] .timepick input{color-scheme:dark}
.timepick .lab{font-size:13.5px; color:var(--text-2)}
.theme-seg{display:flex; gap:8px}
.theme-opt{flex:1; padding:13px; border-radius:var(--r-md); background:var(--surface); border:1.5px solid var(--border);
  display:flex; flex-direction:column; align-items:center; gap:8px; font-size:12.5px; font-weight:500; color:var(--text-2); transition:all .16s}
.theme-opt:hover{border-color:var(--border-strong)}
.theme-opt.sel{border-color:var(--accent); color:var(--accent); background:var(--accent-soft)}

/* Search */
.searchbar{max-width:780px; margin:0 auto; padding:14px 16px 4px}
.searchbox{display:flex; align-items:center; gap:10px; padding:12px 15px; border-radius:var(--r-lg);
  background:var(--surface); border:1px solid var(--border); box-shadow:var(--shadow-sm); transition:border-color .16s,box-shadow .16s}
.searchbox:focus-within{border-color:var(--accent); box-shadow:0 0 0 3px var(--accent-ring)}
.searchbox input{flex:1; border:none; background:none; outline:none; font-size:15.5px; color:var(--text)}
.searchbox input::placeholder{color:var(--text-3)}
.searchbox .go{padding:7px 13px; border-radius:9px; background:var(--accent); color:#fff; font-weight:600; font-size:13px}
.searchbox .go:disabled{opacity:.5}
.searchhint{max-width:780px; margin:0 auto; padding:8px 18px; font-size:12.5px; color:var(--text-3)}

/* scroll-top */
.totop{position:fixed; right:18px; bottom:22px; z-index:50; width:46px; height:46px; border-radius:14px;
  background:var(--accent); color:#fff; display:grid; place-items:center; box-shadow:var(--shadow-md);
  animation:rise .3s ease; transition:background .16s,transform .12s}
.totop:hover{background:var(--accent-hover)}
.totop:active{transform:scale(.9)}

@media (max-width:520px){
  .hdr-in{padding:11px 13px; gap:8px}
  .hdr-actions{gap:0}
  .iconbtn{width:35px; height:35px}
  .brand-mark{font-size:19px; letter-spacing:.1em}
  .main{padding:6px 13px 96px}
  .chips{padding:10px 13px}
  .headline{font-size:16.5px}
  .brand-sub{display:none}
}
@media (prefers-reduced-motion:reduce){
  *{animation-duration:.001ms !important; transition-duration:.001ms !important}
  .pulse span::after{animation:none}
}
`;

/* ------------------------------------------------------------------ */
/*  Kleine UI-Bausteine                                                */
/* ------------------------------------------------------------------ */

function Skeleton() {
  return (
    <div className="sk" aria-hidden="true">
      <div className="sk-line" style={{ width: "30%", height: "9px" }} />
      <div className="sk-line" style={{ width: "92%", height: "15px", marginTop: "12px" }} />
      <div className="sk-line" style={{ width: "70%", height: "15px" }} />
      <div className="sk-line" style={{ width: "100%", marginTop: "12px" }} />
      <div className="sk-line" style={{ width: "55%" }} />
      <div className="sk-line" style={{ width: "38%", height: "20px", marginTop: "12px", borderRadius: "8px" }} />
    </div>
  );
}

function ArticleCard({ article, catName, saved, read, onSave, onRead, index, showCat }) {
  const isTop = article.importance >= 3;
  const isNewUnread = article.isNew && !read;
  return (
    <article
      className={`card${isTop ? " top" : ""}${read ? " read" : ""}`}
      style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }}
    >
      <div className="card-top">
        {isNewUnread && <span className="tag new">Neu</span>}
        {isTop && <span className="tag topstory">Top-Meldung</span>}
        {showCat && <span className="tag cat">{catName}</span>}
      </div>
      <h3 className="headline">{article.headline}</h3>
      {article.summary && <p className="summary">{article.summary}</p>}
      <div className="card-foot">
        {article.sources.length > 0 && (
          <div className="sources">
            {article.sources.map((s, i) => (
              <a
                key={i}
                className="src"
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => onRead(article.id, true)}
                title={s.url}
              >
                <ExternalLink size={12} />
                <span className="nm">{s.name}</span>
              </a>
            ))}
          </div>
        )}
        <div className="foot-row">
          <div className="foot-meta">
            {formatArticleDate(article.date) && <span>{formatArticleDate(article.date)}</span>}
            {formatArticleDate(article.date) && <span className="dotsep" />}
            <span>{timeAgo(article.fetchedAt)} geladen</span>
          </div>
          <button
            className={`act${read ? " isread" : ""}`}
            onClick={() => onRead(article.id)}
            title={read ? "Als ungelesen markieren" : "Als gelesen markieren"}
            aria-label="Gelesen-Status"
          >
            {read ? <Check size={17} /> : <Eye size={17} />}
          </button>
          <button
            className={`act${saved ? " saved" : ""}`}
            onClick={() => onSave(article)}
            title={saved ? "Aus Gespeichert entfernen" : "Speichern"}
            aria-label="Speichern"
          >
            {saved ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}
          </button>
        </div>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/*  Haupt-App                                                          */
/* ------------------------------------------------------------------ */

export default function App() {
  const [theme, setTheme] = useState("light");
  const [categories, setCategories] = useState(
    DEFAULT_CATEGORIES.map((c) => ({ ...c, active: true }))
  );
  const [news, setNews] = useState({}); // {catId:{articles,status,error,fetchedAt}}
  const [savedArticles, setSavedArticles] = useState([]);
  const [readIds, setReadIds] = useState([]);
  const [view, setView] = useState("feed"); // feed|saved|briefing|search
  const [showSettings, setShowSettings] = useState(false);
  const [catFilter, setCatFilter] = useState(null);
  const [timeRange, setTimeRange] = useState("today");
  const [briefingTime, setBriefingTime] = useState("07:30");
  const [banner, setBanner] = useState(false);
  const [newTopic, setNewTopic] = useState("");
  const [searchQ, setSearchQ] = useState("");
  const [searchRun, setSearchRun] = useState(false);
  const [searchRes, setSearchRes] = useState(null);
  const [showTop, setShowTop] = useState(false);
  const [ready, setReady] = useState(false);

  const seenRef = useRef(new Set());
  const loadedBeforeRef = useRef(false);
  const abortRef = useRef(null);
  const settingsLoaded = useRef(false);

  const anyLoading = useMemo(
    () => Object.values(news).some((n) => n && n.status === "loading"),
    [news]
  );
  const readSet = useMemo(() => new Set(readIds), [readIds]);
  const savedSet = useMemo(() => new Set(savedArticles.map((a) => a.id)), [savedArticles]);

  /* ---- Laden beim Start ---- */
  useEffect(() => {
    let alive = true;
    (async () => {
      const [
        sTheme, sCats, sCustom, sRange, sTime,
        sSaved, sRead, sSeen, sLoaded, sCache,
      ] = await Promise.all([
        store.get("theme", null),
        store.get("catState", null),
        store.get("customTopics", []),
        store.get("timeRange", "today"),
        store.get("briefingTime", "07:30"),
        store.get("saved", []),
        store.get("readIds", []),
        store.get("seenIds", null),
        store.get("loadedBefore", false),
        store.get("newsCache", {}),
      ]);
      if (!alive) return;

      const prefersDark =
        typeof window !== "undefined" && window.matchMedia
          ? window.matchMedia("(prefers-color-scheme: dark)").matches
          : false;
      setTheme(sTheme || (prefersDark ? "dark" : "light"));

      let cats = DEFAULT_CATEGORIES.map((c) => ({ ...c, active: true }));
      if (sCats && typeof sCats === "object") {
        cats = cats.map((c) => ({ ...c, active: sCats[c.id] !== false }));
      }
      const customCats = (Array.isArray(sCustom) ? sCustom : []).map((t) => ({
        id: t.id, name: t.name, short: t.name, custom: true,
        active: sCats ? sCats[t.id] !== false : true,
      }));
      cats = [...cats, ...customCats];

      setCategories(cats);
      setTimeRange(sRange || "today");
      setBriefingTime(sTime || "07:30");
      setSavedArticles(Array.isArray(sSaved) ? sSaved : []);
      setReadIds(Array.isArray(sRead) ? sRead : []);
      seenRef.current = new Set(Array.isArray(sSeen) ? sSeen : []);
      loadedBeforeRef.current = !!sLoaded;
      if (sCache && typeof sCache === "object") {
        const restored = {};
        for (const k of Object.keys(sCache)) {
          restored[k] = { ...sCache[k], status: "done" };
        }
        setNews(restored);
      }
      settingsLoaded.current = true;
      setReady(true);
    })();
    return () => { alive = false; };
  }, []);

  /* ---- Theme anwenden + speichern ---- */
  useEffect(() => {
    try { document.documentElement.setAttribute("data-theme", theme); } catch { /* ignore */ }
    if (settingsLoaded.current) store.set("theme", theme);
  }, [theme]);

  /* ---- Fonts laden ---- */
  useEffect(() => {
    const defs = [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossorigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap",
      },
    ];
    const els = defs.map((d) => {
      const el = document.createElement("link");
      Object.entries(d).forEach(([k, v]) => el.setAttribute(k, v));
      document.head.appendChild(el);
      return el;
    });
    return () => els.forEach((el) => el.remove());
  }, []);

  /* ---- Erst-Laden der Nachrichten, sobald bereit ---- */
  useEffect(() => {
    if (!ready) return;
    const stale = [];
    for (const c of categories) {
      if (!c.active) continue;
      const n = news[c.id];
      if (!n || !n.fetchedAt || Date.now() - n.fetchedAt > FRESH_MS || !n.articles || n.articles.length === 0) {
        stale.push(c);
      }
    }
    if (stale.length) loadCats(stale, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  /* ---- Stündliche Auto-Aktualisierung ---- */
  useEffect(() => {
    if (!ready) return;
    const iv = setInterval(() => {
      const active = categories.filter((c) => c.active);
      if (active.length) loadCats(active, true);
    }, FRESH_MS);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, categories, timeRange]);

  /* ---- Briefing-Banner prüfen ---- */
  useEffect(() => {
    if (!ready) return;
    let stop = false;
    const check = async () => {
      const now = new Date();
      const [hh, mm] = (briefingTime || "07:30").split(":").map(Number);
      const todayKey = now.toISOString().slice(0, 10);
      const past = now.getHours() > hh || (now.getHours() === hh && now.getMinutes() >= mm);
      const lastShown = await store.get("briefingShown", "");
      if (!stop && past && lastShown !== todayKey) setBanner(true);
    };
    check();
    const iv = setInterval(check, 60 * 1000);
    return () => { stop = true; clearInterval(iv); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, briefingTime]);

  /* ---- Scroll-to-top Sichtbarkeit ---- */
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* ---- Persistenz-Helfer ---- */
  const persistCats = useCallback((cats) => {
    const map = {};
    cats.forEach((c) => { map[c.id] = c.active; });
    store.set("catState", map);
    store.set("customTopics", cats.filter((c) => c.custom).map((c) => ({ id: c.id, name: c.name })));
  }, []);

  /* ---- Nachrichten laden ---- */
  const loadCats = useCallback(async (cats, isRefresh) => {
    if (abortRef.current) abortRef.current.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    // Vor einem Refresh: bisher angezeigte IDs als "gesehen" merken
    if (isRefresh) {
      setNews((prev) => {
        for (const k of Object.keys(prev)) {
          (prev[k].articles || []).forEach((a) => seenRef.current.add(a.id));
        }
        return prev;
      });
      store.set("seenIds", Array.from(seenRef.current).slice(-1200));
    }

    const ordered = [...cats].sort((a, b) => (b.isLocal ? 1 : 0) - (a.isLocal ? 1 : 0));
    ordered.forEach((c) =>
      setNews((p) => ({ ...p, [c.id]: { ...(p[c.id] || {}), status: "loading", error: null } }))
    );

    const firstRun = !loadedBeforeRef.current;
    let idx = 0;
    const worker = async () => {
      while (idx < ordered.length) {
        const cat = ordered[idx++];
        try {
          const articles = await fetchCategoryFeeds(cat, ctrl.signal);
          const withNew = articles.map((a) => ({
            ...a,
            isNew: !firstRun && !seenRef.current.has(a.id),
          }));
          setNews((p) => {
            const next = {
              ...p,
              [cat.id]: { articles: withNew, status: "done", error: null, fetchedAt: Date.now() },
            };
            const cache = {};
            for (const k of Object.keys(next)) {
              if (next[k].articles && next[k].articles.length) {
                cache[k] = { articles: next[k].articles, fetchedAt: next[k].fetchedAt };
              }
            }
            store.set("newsCache", cache);
            return next;
          });
        } catch (e) {
          if (e.name === "AbortError") return;
          setNews((p) => ({
            ...p,
            [cat.id]: { ...(p[cat.id] || {}), status: "error", error: e.message || "Fehler" },
          }));
        }
      }
    };

    await Promise.all([worker(), worker(), worker()]);

    // Alle aktuellen IDs als gesehen markieren (für künftiges "Neu")
    setNews((prev) => {
      for (const k of Object.keys(prev)) {
        (prev[k].articles || []).forEach((a) => seenRef.current.add(a.id));
      }
      return prev;
    });
    store.set("seenIds", Array.from(seenRef.current).slice(-1200));
    loadedBeforeRef.current = true;
    store.set("loadedBefore", true);
  }, [timeRange]);

  /* ---- Aktionen ---- */
  const refreshAll = useCallback(() => {
    const active = categories.filter((c) => c.active);
    if (active.length) loadCats(active, true);
  }, [categories, loadCats]);

  const toggleSave = useCallback((article) => {
    setSavedArticles((prev) => {
      const exists = prev.some((a) => a.id === article.id);
      const next = exists ? prev.filter((a) => a.id !== article.id) : [{ ...article, savedAt: Date.now() }, ...prev];
      store.set("saved", next);
      return next;
    });
  }, []);

  const toggleRead = useCallback((id, forceRead) => {
    setReadIds((prev) => {
      const has = prev.includes(id);
      let next;
      if (forceRead) next = has ? prev : [...prev, id];
      else next = has ? prev.filter((x) => x !== id) : [...prev, id];
      store.set("readIds", next);
      return next;
    });
  }, []);

  const setCatActive = useCallback((id, active) => {
    setCategories((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, active } : c));
      persistCats(next);
      if (active) {
        const cat = next.find((c) => c.id === id);
        const n = news[id];
        if (cat && (!n || !n.articles || n.articles.length === 0)) loadCats([cat], false);
      }
      return next;
    });
  }, [news, loadCats, persistCats]);

  const addTopic = useCallback(() => {
    const name = newTopic.trim();
    if (!name) return;
    const id = "custom-" + hashStr(name + Date.now());
    const cat = { id, name, short: name, custom: true, active: true };
    setCategories((prev) => {
      const next = [...prev, cat];
      persistCats(next);
      return next;
    });
    setNewTopic("");
    loadCats([cat], false);
  }, [newTopic, persistCats, loadCats]);

  const removeTopic = useCallback((id) => {
    setCategories((prev) => {
      const next = prev.filter((c) => c.id !== id);
      persistCats(next);
      return next;
    });
    setNews((p) => { const n = { ...p }; delete n[id]; return n; });
  }, [persistCats]);

  // Bei RSS ist der Zeitraum nur ein Anzeigefilter – kein Neuladen nötig.
  const changeRange = useCallback((r) => {
    setTimeRange(r);
    store.set("timeRange", r);
  }, []);

  const setBriefingTimeP = useCallback((t) => {
    setBriefingTime(t);
    store.set("briefingTime", t);
  }, []);

  const openBriefing = useCallback(() => {
    setBanner(false);
    setView("briefing");
    const todayKey = new Date().toISOString().slice(0, 10);
    store.set("briefingShown", todayKey);
  }, []);

  const dismissBanner = useCallback(() => {
    setBanner(false);
    const todayKey = new Date().toISOString().slice(0, 10);
    store.set("briefingShown", todayKey);
  }, []);

  const runSearch = useCallback(async () => {
    const q = searchQ.trim();
    if (!q) return;
    setSearchRun(true);
    setSearchRes(null);
    try {
      const cat = { id: "search-" + hashStr(q), name: q, short: q };
      const feed = googleNewsFeed(q);
      const xml = await fetchViaProxy(feed.url, null);
      const articles = parseFeed(xml, feed, cat).slice(0, 25);
      setSearchRes(articles);
    } catch (e) {
      setSearchRes({ error: e.message || "Suche fehlgeschlagen" });
    } finally {
      setSearchRun(false);
    }
  }, [searchQ]);

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  /* ---- abgeleitete Daten ---- */
  const catName = useCallback(
    (id) => {
      const c = categories.find((x) => x.id === id);
      if (c) return c.name;
      if (typeof id === "string" && id.startsWith("search-")) return "Suche";
      return "Meldung";
    },
    [categories]
  );

  const briefingArticles = useMemo(() => {
    const out = [];
    for (const c of categories) {
      if (!c.active) continue;
      const arts = (news[c.id] && news[c.id].articles) || [];
      const sorted = [...arts].sort((a, b) => (b.ts || 0) - (a.ts || 0));
      sorted.slice(0, 2).forEach((a) => out.push(a));
    }
    return out.sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, 16);
  }, [categories, news]);

  const visibleCats = useMemo(() => {
    let list = categories.filter((c) => c.active);
    list = [...list].sort((a, b) => (b.isLocal ? 1 : 0) - (a.isLocal ? 1 : 0));
    if (catFilter) list = list.filter((c) => c.id === catFilter);
    return list;
  }, [categories, catFilter]);

  /* ------------------------------------------------------------------ */
  /*  Render                                                            */
  /* ------------------------------------------------------------------ */

  const todayLabel = new Date().toLocaleDateString("de-DE", { day: "2-digit", month: "long" });

  return (
    <div className="app" data-theme={theme}>
      <style>{STYLES}</style>

      {/* Header */}
      <header className="hdr">
        <div className="hdr-in">
          <button className="brand" onClick={() => { setView("feed"); setCatFilter(null); scrollTop(); }} aria-label="Zur Startseite">
            <span className="brand-mark">{APP_NAME}</span>
            <span className="brand-sub">
              <span className="pulse"><span /></span>
              Mittelbaden · Welt
            </span>
          </button>
          <div className="hdr-actions">
            <button className={`iconbtn${view === "search" ? " on" : ""}`} onClick={() => setView(view === "search" ? "feed" : "search")} title="Suchen" aria-label="Suchen">
              <Search size={19} />
            </button>
            <button className={`iconbtn${view === "briefing" ? " on" : ""}`} onClick={() => setView(view === "briefing" ? "feed" : "briefing")} title="Tages-Briefing" aria-label="Briefing">
              <Bell size={19} />
              {banner && <span className="dot" />}
            </button>
            <button className={`iconbtn${view === "saved" ? " on" : ""}`} onClick={() => setView(view === "saved" ? "feed" : "saved")} title="Gespeichert" aria-label="Gespeichert">
              <Bookmark size={19} />
              {savedArticles.length > 0 && <span className="dot" />}
            </button>
            <button className="iconbtn" onClick={refreshAll} title="Aktualisieren" aria-label="Aktualisieren">
              <RefreshCw size={18} className={anyLoading ? "spin" : ""} />
            </button>
            <button className="iconbtn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title="Hell/Dunkel" aria-label="Design wechseln">
              {theme === "dark" ? <Sun size={19} /> : <Moon size={18} />}
            </button>
            <button className="iconbtn" onClick={() => setShowSettings(true)} title="Einstellungen" aria-label="Einstellungen">
              <Settings size={19} />
            </button>
          </div>
        </div>

        {/* Kategorie-Chips nur im Feed */}
        {view === "feed" && (
          <div className="chips-wrap">
            <div className="chips">
              <button className={`chip${!catFilter ? " active" : ""}`} onClick={() => setCatFilter(null)}>
                Alle
              </button>
              {categories.filter((c) => c.active).sort((a, b) => (b.isLocal ? 1 : 0) - (a.isLocal ? 1 : 0)).map((c) => (
                <button
                  key={c.id}
                  className={`chip${catFilter === c.id ? " active" : ""}${c.isLocal ? " local" : ""}`}
                  onClick={() => setCatFilter(c.id)}
                >
                  {c.isLocal && <MapPin size={12} />}
                  {c.short || c.name}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Briefing-Banner */}
      {banner && view !== "briefing" && (
        <div className="banner">
          <div className="banner-in">
            <div className="banner-ic"><Sparkles size={19} /></div>
            <div className="banner-tx">
              <b>Dein Tages-Briefing ist bereit</b>
              <span>Die wichtigsten Meldungen für {todayLabel}</span>
            </div>
            <button className="banner-go" onClick={openBriefing}>Ansehen <ChevronRight size={16} /></button>
            <button className="banner-x" onClick={dismissBanner} aria-label="Schließen"><X size={16} /></button>
          </div>
        </div>
      )}

      {/* Zeitraum-Leiste im Feed */}
      {view === "feed" && (
        <div className="subbar">
          <div className="seg">
            <button className={timeRange === "today" ? "active" : ""} onClick={() => changeRange("today")}>HEUTE</button>
            <button className={timeRange === "7days" ? "active" : ""} onClick={() => changeRange("7days")}>7 TAGE</button>
          </div>
          <span className="subbar-note"><Radio size={11} /> stündlich aktualisiert</span>
        </div>
      )}

      <main className="main">
        {/* FEED */}
        {view === "feed" && visibleCats.map((c, ci) => {
          const n = news[c.id] || {};
          const arts = n.articles || [];
          const shown = arts.filter((a) => passesRange(a, timeRange));
          return (
            <section key={c.id} className={`section${ci === 0 ? " first" : ""}${c.isLocal ? " local" : ""}`}>
              <div className="sec-head">
                <span className="sec-rail" />
                <span className="sec-title">{c.name}</span>
                {shown.length > 0 && <span className="sec-count">{shown.length}</span>}
                {c.isLocal && <span className="sec-loc-tag"><MapPin size={11} /> Karlsruhe · Rastatt · Baden-Baden</span>}
              </div>

              {(n.status === "loading" || !n.status) && arts.length === 0 && (
                <>
                  <Skeleton /><Skeleton />
                </>
              )}

              {n.status === "error" && arts.length === 0 && (
                <div className="cat-error">
                  <AlertCircle size={17} />
                  <span>Konnte „{c.name}" nicht laden.</span>
                  <button onClick={() => loadCats([c], false)}><RefreshCw size={13} /> Erneut</button>
                </div>
              )}

              {arts.length === 0 && n.status === "done" && (
                <div className="cat-error">
                  <Inbox size={17} />
                  <span>Aktuell keine Meldungen zu „{c.name}".</span>
                  <button onClick={() => loadCats([c], false)}><RefreshCw size={13} /> Neu laden</button>
                </div>
              )}

              {arts.length > 0 && shown.length === 0 && n.status === "done" && timeRange === "today" && (
                <div className="cat-error">
                  <Clock size={17} />
                  <span>Heute noch nichts Neues bei „{c.name}".</span>
                  <button onClick={() => changeRange("7days")}><ChevronRight size={13} /> 7 Tage zeigen</button>
                </div>
              )}

              {shown.map((a, i) => (
                <ArticleCard
                  key={a.id}
                  article={a}
                  index={i}
                  catName={c.name}
                  saved={savedSet.has(a.id)}
                  read={readSet.has(a.id)}
                  onSave={toggleSave}
                  onRead={toggleRead}
                  showCat={false}
                />
              ))}
            </section>
          );
        })}

        {view === "feed" && visibleCats.length === 0 && (
          <div className="state">
            <div className="ic"><Globe size={26} /></div>
            <h3>Keine Kategorien aktiv</h3>
            <p>Aktiviere in den Einstellungen Themen, die dich interessieren.</p>
            <button className="retry" onClick={() => setShowSettings(true)}><Settings size={15} /> Einstellungen öffnen</button>
          </div>
        )}

        {/* GESPEICHERT */}
        {view === "saved" && (
          <section className="section first">
            <div className="sec-head">
              <span className="sec-rail" />
              <span className="sec-title">Gespeichert</span>
              {savedArticles.length > 0 && <span className="sec-count">{savedArticles.length}</span>}
            </div>
            {savedArticles.length === 0 ? (
              <div className="state">
                <div className="ic"><Bookmark size={24} /></div>
                <h3>Noch nichts gespeichert</h3>
                <p>Tippe bei einer Meldung auf das Lesezeichen, um sie hier abzulegen.</p>
              </div>
            ) : (
              savedArticles.map((a, i) => (
                <ArticleCard
                  key={a.id}
                  article={a}
                  index={i}
                  catName={catName(a.categoryId)}
                  saved={true}
                  read={readSet.has(a.id)}
                  onSave={toggleSave}
                  onRead={toggleRead}
                  showCat={true}
                />
              ))
            )}
          </section>
        )}

        {/* BRIEFING */}
        {view === "briefing" && (
          <section className="section first">
            <div className="sec-head">
              <span className="sec-rail" style={{ background: "var(--accent)" }} />
              <span className="sec-title" style={{ color: "var(--accent)" }}>Tages-Briefing</span>
              <span className="sec-loc-tag"><Clock size={11} /> {todayLabel}</span>
            </div>
            {briefingArticles.length === 0 ? (
              <div className="state">
                <div className="ic"><Sparkles size={24} /></div>
                <h3>Briefing wird vorbereitet</h3>
                <p>Sobald Meldungen geladen sind, erscheinen hier die wichtigsten des Tages.</p>
                <button className="retry" onClick={refreshAll}><RefreshCw size={15} /> Jetzt laden</button>
              </div>
            ) : (
              briefingArticles.map((a, i) => (
                <ArticleCard
                  key={a.id + "-b"}
                  article={a}
                  index={i}
                  catName={catName(a.categoryId)}
                  saved={savedSet.has(a.id)}
                  read={readSet.has(a.id)}
                  onSave={toggleSave}
                  onRead={toggleRead}
                  showCat={true}
                />
              ))
            )}
          </section>
        )}

        {/* SUCHE */}
        {view === "search" && (
          <>
            <div className="searchbar">
              <div className="searchbox">
                <Search size={19} color="var(--text-3)" />
                <input
                  autoFocus
                  value={searchQ}
                  onChange={(e) => setSearchQ(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") runSearch(); }}
                  placeholder="Eigenes Thema suchen, z. B. Nvidia RTX 5090"
                />
                <button className="go" onClick={runSearch} disabled={searchRun || !searchQ.trim()}>
                  {searchRun ? "…" : "Suchen"}
                </button>
              </div>
            </div>
            <div className="searchhint">Durchsucht aktuelle, seriöse Quellen zu deinem Stichwort.</div>

            <section className="section" style={{ marginTop: "14px" }}>
              {searchRun && (<><Skeleton /><Skeleton /></>)}
              {searchRes && searchRes.error && (
                <div className="cat-error">
                  <AlertCircle size={17} />
                  <span>{searchRes.error}</span>
                  <button onClick={runSearch}><RefreshCw size={13} /> Erneut</button>
                </div>
              )}
              {Array.isArray(searchRes) && searchRes.length === 0 && (
                <div className="state">
                  <div className="ic"><Inbox size={24} /></div>
                  <h3>Nichts gefunden</h3>
                  <p>Versuch ein anderes Stichwort oder formuliere es etwas breiter.</p>
                </div>
              )}
              {Array.isArray(searchRes) && searchRes.map((a, i) => (
                <ArticleCard
                  key={a.id}
                  article={a}
                  index={i}
                  catName="Suche"
                  saved={savedSet.has(a.id)}
                  read={readSet.has(a.id)}
                  onSave={toggleSave}
                  onRead={toggleRead}
                  showCat={false}
                />
              ))}
              {!searchRun && !searchRes && (
                <div className="state">
                  <div className="ic"><Search size={24} /></div>
                  <h3>Wonach suchst du?</h3>
                  <p>Gib oben ein Stichwort ein und drücke Enter.</p>
                </div>
              )}
            </section>
          </>
        )}
      </main>

      {/* Scroll-to-top */}
      {showTop && (
        <button className="totop" onClick={scrollTop} aria-label="Nach oben"><ArrowUp size={20} /></button>
      )}

      {/* Einstellungen */}
      {showSettings && (
        <div className="scrim" onClick={(e) => { if (e.target === e.currentTarget) setShowSettings(false); }}>
          <div className="panel">
            <div className="panel-hd">
              <h2>Einstellungen</h2>
              <button className="iconbtn" onClick={() => setShowSettings(false)} aria-label="Schließen"><X size={20} /></button>
            </div>
            <div className="panel-body">

              <div className="pgroup">
                <div className="pgroup-t"><Sun size={12} /> Darstellung</div>
                <div className="theme-seg">
                  <button className={`theme-opt${theme === "light" ? " sel" : ""}`} onClick={() => setTheme("light")}>
                    <Sun size={20} /> Hell
                  </button>
                  <button className={`theme-opt${theme === "dark" ? " sel" : ""}`} onClick={() => setTheme("dark")}>
                    <Moon size={19} /> Dunkel
                  </button>
                </div>
              </div>

              <div className="pgroup">
                <div className="pgroup-t"><Bell size={12} /> Tages-Briefing</div>
                <div className="timepick">
                  <Clock size={18} color="var(--text-2)" />
                  <span className="lab">Bereit ab</span>
                  <input
                    type="time"
                    value={briefingTime}
                    onChange={(e) => setBriefingTimeP(e.target.value)}
                    style={{ marginLeft: "auto" }}
                  />
                </div>
              </div>

              <div className="pgroup">
                <div className="pgroup-t"><Plus size={12} /> Eigenes Thema</div>
                <div className="addrow">
                  <input
                    className="inp"
                    value={newTopic}
                    onChange={(e) => setNewTopic(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") addTopic(); }}
                    placeholder="z. B. Heimkino, ESP32, Quantencomputer"
                  />
                  <button className="btn-p" onClick={addTopic} disabled={!newTopic.trim()}><Plus size={16} /> Hinzu</button>
                </div>
              </div>

              <div className="pgroup">
                <div className="pgroup-t"><Globe size={12} /> Kategorien</div>
                {[...categories].sort((a, b) => (b.isLocal ? 1 : 0) - (a.isLocal ? 1 : 0)).map((c) => (
                  <div key={c.id} className={`catrow${c.isLocal ? " local" : ""}`}>
                    {c.isLocal && <MapPin size={16} color="var(--accent)" />}
                    <div className="nm">
                      {c.name}
                      {c.isLocal && <small>Karlsruhe · Rastatt · Baden-Baden</small>}
                      {c.custom && <small>Eigenes Thema</small>}
                    </div>
                    {c.custom && (
                      <button className="rm" onClick={() => removeTopic(c.id)} title="Thema entfernen" aria-label="Entfernen">
                        <Trash2 size={15} />
                      </button>
                    )}
                    <button
                      className={`switch${c.active ? " on" : ""}`}
                      onClick={() => setCatActive(c.id, !c.active)}
                      role="switch"
                      aria-checked={c.active}
                      aria-label={`${c.name} ${c.active ? "aktiv" : "inaktiv"}`}
                    >
                      <i />
                    </button>
                  </div>
                ))}
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}
