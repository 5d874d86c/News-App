import React from "react";
import { createRoot } from "react-dom/client";
import RadarRSS from "./RadarRSS.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RadarRSS />
  </React.StrictMode>
);
