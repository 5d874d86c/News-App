# RADAR – RSS-Version

Persönlicher Nachrichten-Aggregator auf Basis kostenloser RSS-Feeds.
Lokalteil Mittelbaden (Karlsruhe, Rastatt, Baden-Baden) plus 13 weitere
Themen. Keine KI, kein API-Key, keine Kosten.

## Starten

Voraussetzung: Node.js 18 oder neuer.

```bash
npm install
npm run dev
```

Danach öffnet sich die App unter `http://localhost:5173`.

## Wichtig: CORS-Proxy

Browser dürfen RSS-Feeds fremder Seiten nicht direkt laden. Die App holt
die Feeds deshalb über einen öffentlichen CORS-Proxy
(`allorigins.win`, mit `corsproxy.io` als Reserve, danach Direktversuch).

Lokal über `npm run dev` funktioniert das in der Regel zuverlässig. Falls
einzelne Kategorien leer bleiben, ist meist der jeweilige Feed kurz nicht
erreichbar – die anderen Feeds der Kategorie liefern trotzdem.

Wer dauerhaft unabhängig von öffentlichen Proxys sein will, kann einen
eigenen kleinen Proxy betreiben und die Liste `PROXIES` in
`src/RadarRSS.jsx` darauf umstellen.

## Feeds anpassen

Alle Quellen stehen gebündelt in `src/RadarRSS.jsx` in der Konstante
`FEEDS` – pro Kategorie eine Liste aus `{ name, url }`. Einfach Einträge
ergänzen, austauschen oder entfernen. Fällt ein Feed aus, übernehmen die
übrigen Feeds derselben Kategorie.

Eigene Themen (in den Einstellungen der App) und die Suche laufen über
Google-News-RSS und brauchen keine Konfiguration.

## Produktiv bauen

```bash
npm run build      # erzeugt den Ordner dist/
npm run preview    # dist/ lokal testen
```

Den Inhalt von `dist/` kann man auf jedem statischen Webhost ablegen
(z. B. Netlify, GitHub Pages, eigener Server).

## Daten

Gespeicherte Artikel, gelesene Meldungen und Einstellungen liegen im
`localStorage` des Browsers (Schlüssel mit Präfix `radar:`). Sie bleiben
über Neustarts erhalten und verlassen das Gerät nicht.

## Struktur

```
radar-rss/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx        Einstiegspunkt
    └── RadarRSS.jsx    gesamte App inkl. Feeds, Parser und UI
```
